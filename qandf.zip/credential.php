<?php 

define('EMAIL', 'funqandf@gmail.com');
define('PASS', 'qandf@gmail');

 ?>