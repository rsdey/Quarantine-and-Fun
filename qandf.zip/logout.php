<?php 

session_start();

session_destroy();


 				?>
 				<script>alert('Logout Successful !');
 				location.replace("index.php");
 				</script>
 				
 				<?php

 ?>
