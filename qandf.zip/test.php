<?php 

$msg='hi';
$t='rd';
echo 'bye'.$msg.$t.'hello';

 ?>
